<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class H_empresas extends Model
{
//    use HasFactory;
    protected $table = "hsp_empresas";
    protected $primaryKey = 'id';
}
