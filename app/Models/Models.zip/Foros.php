<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Foros extends Model
{
    protected $table = "foros";
    protected $primaryKey = 'id_foro';
}
