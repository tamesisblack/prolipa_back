<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cumplimientos extends Model
{
    protected $table = "ctrl_avances";
    protected $primaryKey = 'id_avance';
}
