<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PedidosAsesores extends Model
{
    protected $table = "pedidos_asesores";
    protected $primaryKey = 'id';
}
