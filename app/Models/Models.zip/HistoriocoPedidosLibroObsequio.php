<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HistoriocoPedidosLibroObsequio extends Model
{
    use HasFactory;
    protected $table  ="p_historico_libros_obsequios";
    public $timestamps = false;
}
