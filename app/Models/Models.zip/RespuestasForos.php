<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RespuestasForos extends Model
{
    protected $table = "foros_respuestas";
    protected $primaryKey = 'id';
}
