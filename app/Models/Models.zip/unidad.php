<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class unidad extends Model
{
    //
    protected $table = "unidades_libros";
    protected $primaryKey = 'id_unidad_libro';
}
