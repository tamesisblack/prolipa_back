<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SallePreguntas extends Model
{
    protected $table = "salle_preguntas";
    protected $primaryKey = 'id_pregunta';
}
