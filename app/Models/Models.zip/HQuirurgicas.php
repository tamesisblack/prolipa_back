<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HQuirurgicas extends Model
{
    // use HasFactory;
    protected $table = "hsp_quirugicas";
    protected $primaryKey = 'id';
}
