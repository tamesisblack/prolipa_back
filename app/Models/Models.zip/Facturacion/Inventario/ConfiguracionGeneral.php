<?php

namespace App\Models\Facturacion\Inventario;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConfiguracionGeneral extends Model
{
    use HasFactory;
    protected $table = "configuracion_general";
}
