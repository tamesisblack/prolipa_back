<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pacientes extends Model
{
    protected $table = "nh_pacientes";
    protected $primaryKey = 'id_paciente';
}
