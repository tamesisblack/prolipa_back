<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Proformahistorico extends Model
{
    use HasFactory;
    protected $table = "f_proforma_historico";
    

}
