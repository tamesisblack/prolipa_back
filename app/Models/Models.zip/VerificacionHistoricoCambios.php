<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VerificacionHistoricoCambios extends Model
{
    use HasFactory;
    protected $table = "verificaciones_historico_cambios";
}
