<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NeetUploadSubTema extends Model
{
    use HasFactory;
    protected $table = "neet_upload_subtemas";
    protected $primaryKey ="id";
}
