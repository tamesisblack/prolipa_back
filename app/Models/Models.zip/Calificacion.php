<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Calificacion extends Model
{
    protected $table = "usuario_tarea";
	public $timestamps = false;
}
