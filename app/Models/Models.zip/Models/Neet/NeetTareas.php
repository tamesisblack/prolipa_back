<?php

namespace App\Models\Models\Neet;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NeetTareas extends Model
{
    use HasFactory;
    protected $table = "neet_tareas";
}
