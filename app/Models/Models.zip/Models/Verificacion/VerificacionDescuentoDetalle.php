<?php

namespace App\Models\Models\Verificacion;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VerificacionDescuentoDetalle extends Model
{
    use HasFactory;
    protected $table = "verificaciones_descuentos_detalle";
}
