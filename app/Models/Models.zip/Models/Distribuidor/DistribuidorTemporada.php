<?php

namespace App\Models\Models\Distribuidor;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DistribuidorTemporada extends Model
{
    use HasFactory;
    protected $table = "distribuidor_temporada";
}
