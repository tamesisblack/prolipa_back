<?php

namespace App\Models\Models\Pagos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VerificacionPagoDetalle extends Model
{
    use HasFactory;
    protected $table = "verificaciones_pagos_detalles";
}
