<?php

namespace App\Models\Models\Pagos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DistribuidorHistorico extends Model
{
    use HasFactory;
    protected $table = "distribuidor_historico";
}
